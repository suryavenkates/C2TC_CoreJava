package datatype;

public class dtype {

	public static void main(String[] args) {
		int value1 = 9/2;
		System.out.println(value1);

		float value2 = 110f/40f;
		System.out.println(value2);
		
		double value3 = 10d/3d;
		System.out.println(value3);	
	
		double value4 = 1.6666d;
		System.out.println(value4);
		
		int marker = 512;
		float percentage = marker * 0.46f;
		System.out.print(percentage);
	}
}
