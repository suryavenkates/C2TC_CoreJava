package datatype;

public class CharDemo {

	public static void main(String[] args) {
		
		char ch = 'a';
		System.out.println(ch);
		
		char ch1 = 65;
		System.out.println(ch1);

		char ch2 = '\u00a7';
		System.out.println(ch2);
		
		char ch3 = '\u20ac';
		System.out.println(ch3);
		
		int a = 't';
		System.out.println(a);
	}

}
